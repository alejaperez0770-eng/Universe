OUR LITTLE UNIVERSE — DELUXE NEOCITIES EDITION

1. Abre index.html en un navegador.
2. Pon tu GIF de Godzilla en assets/godzilla.gif
3. Pon tu GIF de Hatsune Miku en assets/miku.gif
4. No necesitas servidor: funciona como sitio estático.
5. La ruleta, favoritos, guestbook, calendario, planes guardados y listas usan localStorage del navegador.

Estructura:
- index.html = estructura
- style.css = diseño / estética / responsive
- script.js = ruleta, actividades, juegos, scrapbook, etc.
- assets/ = tus GIFs y futuras imágenes

Hay más de 2000 ideas de citas/actividades, 20 manualidades, arcade, ventanas tipo 90s/NeoCities, easter egg de Godzilla, contador de visitas local, modo panic, calendario y almacenamiento local.

Si quieres publicar la web, súbela como sitio estático a Neocities, GitHub Pages, Netlify o cualquier hosting de HTML.


APP (PWA):
- Al subir la web a GitHub Pages (https), se puede instalar como app.
- iPhone: Safari > Compartir > Añadir a pantalla de inicio.
- Android: Chrome > menú > Instalar app.
- Si cambias archivos y la app no se actualiza, sube el número de CACHE en service-worker.js (olu-v1 > olu-v2).
